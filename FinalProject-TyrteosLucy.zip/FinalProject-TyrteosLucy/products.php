<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Origin, Content-Type, Accept, Authorization, X-Request-With');
header('Content-Type: application/json');
/*
Cart Information, array of:
- Item id
- Item name
- Item quantity

This file will generate an order confirmation id and will return the following information in JSON format:
- order confirmation id (use the php function uniqid(), see https://www.php.net/manual/en/function.uniqid.php)
- first name
- last name
- email address

array of:
- item id
- item name
- item qty

*/
$products = [
        [
         "id" => "b92d300d-6504-4dbd-8ec0-e07856a8b1a7",
         "name" => "Eucalyptus", 
         "unitCost" => 7.00, 
         "quantity" => 1
        ],
        [
         "id" => "77b72895-e2fa-4614-bfbb-5c216880c4a6", 
         "name" => "Lavender", 
         "unitCost" => 9.00, 
         "quantity" => 1
        ],
        [
         "id" => "c5f8887b-5000-4832-856b-5abfd8d4fe24", 
         "name" => "Peppermint", 
         "unitCost" => 7.00, 
         "quantity" => 1
        ],
        [
         "id" => "c02461bb-2eb8-4f75-8f58-f831bcfffbd8", 
         "name" => "Bergamot", 
         "unitCost" => 11.00, 
         "quantity" => 1
        ],
        [
         "id" => "c5a30dcb-4e5f-4ec3-8e30-d23806927c9b", 
         "name" => "Oregano", 
         "unitCost" => 9.00, 
         "quantity" => 1
        ]
     ];


echo json_encode($products);

?>