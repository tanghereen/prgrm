<?php
header('Access-Control-Allow-Origin: *'); 
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Origin, Content-Type, Accept, Authorization, X-Request-With');
header('Content-Type: application/json');
/* This file will receive the user and cart information via POST parameters:

User Information

- First name
- Last name
- Email address

- Street Address
- City
- State
- Postal Code
*/

    foreach($_POST as $key => $value){
        print "{$key}: \"{$value}\"<br>";
    }
    foreach($_GET as $key => $value){
        print "{$key}: \"{$value}\"<br>";
    }

$content = file_get_contents("php://input");
$userInfo = json_decode($content, true);

$id = uniqid();
$userInfo = [ 'first' => $firstName, 'last' => $lastName, 'email' => $emailAddress, 'address' => $streetAddress, 'city' => $userCity, 'state' => $userState, 'zip' => $userZip ];

echo json_encode($userInfo);
?>